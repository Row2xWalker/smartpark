package com.example.smartpark.api.controller;

import com.example.smartpark.api.model.Vehicle;
import com.example.smartpark.service.VehicleService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

@RestController
@RequestMapping("/api")
@Validated
public class VehicleController {

    private final VehicleService vehicleService;
    @Autowired
    public VehicleController(VehicleService vehicleService){
        this.vehicleService = vehicleService;
    }

    @GetMapping("/vehicle")
    public ResponseEntity<Vehicle> getVehicle(@RequestParam String licensePlate) {
        Optional<Vehicle> vehicle = vehicleService.getVehicle(licensePlate);

        return vehicle
                .map(ResponseEntity::ok)  // Return the vehicle with a 200 OK if found
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());  // Return 404 Not Found if not found
    }

    // POST Request: Add a new vehicle
    @PostMapping("/vehicle")
    public ResponseEntity<Vehicle> addVehicle(@RequestBody Vehicle vehicle) {
        // Validate the Vehicle data
        System.out.println("vehicle:"+ vehicle);
        if (vehicle.getLicensePlate() == null || vehicle.getLicensePlate().trim().isEmpty()) {
            return ResponseEntity.badRequest().build();  // Return 400 Bad Request if vehicle id is missing
        }

        // Optionally, check if the Vehicle already exists
        Optional<Vehicle> existingVehicle = vehicleService.getVehicle(vehicle.getLicensePlate());
        if (existingVehicle.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();  // Return 409 Conflict if the lotId already exists
        }

        // Add the new vehicle
        Vehicle newVehicle = vehicleService.addVehicle(vehicle);
        return ResponseEntity.status(HttpStatus.CREATED).body(newVehicle); // Return 201 Created for successful addition
    }

    // Check-in a vehicle to a specific parking lot
    @PostMapping("/vehicle/{vehicleId}/check-in")
    public ResponseEntity<Vehicle> checkInVehicle(@PathVariable Long vehicleId, @RequestParam Long parkingLotId) {
        try {
            Vehicle checkedInVehicle = vehicleService.checkInVehicle(vehicleId, parkingLotId);
            return ResponseEntity.ok(checkedInVehicle); // Return 200 OK with the vehicle details
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build(); // Return 400 Bad Request if something goes wrong
        }
    }

    // Check-out a vehicle from a specific parking lot
    @PostMapping("/vehicle/{vehicleId}/check-out")
    public ResponseEntity<Vehicle> checkOutVehicle(@PathVariable Long vehicleId, @RequestParam Long parkingLotId) {
        try {
            Vehicle checkedOutVehicle = vehicleService.checkOutVehicle(vehicleId, parkingLotId);
            return ResponseEntity.ok(checkedOutVehicle); // Return 200 OK with the vehicle details
        } catch (RuntimeException e) {
            return ResponseEntity.status(HttpStatus.BAD_REQUEST).build(); // Return 400 Bad Request if something goes wrong
        }
    }
}
