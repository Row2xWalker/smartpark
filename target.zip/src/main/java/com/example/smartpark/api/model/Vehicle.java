package com.example.smartpark.api.model;

import com.fasterxml.jackson.annotation.JsonCreator;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.Entity;
import jakarta.persistence.Id;

import javax.validation.constraints.NotNull;

@Entity
public class Vehicle {
    @Id
    @NotNull
    private String licensePlate;
    private String type; // "Car", "Motorcycle", "Truck"
    private String ownerName;

    public Vehicle() {
        // Default constructor required by JPA
    }
    @JsonCreator
    public Vehicle(
            @JsonProperty("licensePlate") String licensePlate,
            @JsonProperty("type") String type,
            @JsonProperty("ownerName") String ownerName
    ) {
        this.licensePlate = licensePlate;
        this.type = type;
        this.ownerName = ownerName;
    }

    public String getLicensePlate(){
        return licensePlate;
    }

    public void setLicensePlate(String licensePlate) {
        this.licensePlate = licensePlate;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getOwnerName() {
        return ownerName;
    }

    public void setOwnerName(String ownerName) {
        this.ownerName = ownerName;
    }
}
