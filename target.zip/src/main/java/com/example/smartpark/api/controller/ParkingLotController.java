package com.example.smartpark.api.controller;

import java.util.Optional;
import com.example.smartpark.api.model.ParkingLot;
import com.example.smartpark.service.ParkingLotService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;

@RestController
@RequestMapping("/api")
@Validated
public class ParkingLotController {
    private final ParkingLotService parkingLotService;

    @Autowired
    public ParkingLotController(ParkingLotService parkingLotService) {
        this.parkingLotService = parkingLotService;
    }

    @GetMapping("/parking-lot")
    public ResponseEntity<ParkingLot> getParkingLot(@RequestParam String lotId) {
        Optional<ParkingLot> parkingLot = parkingLotService.getParkingLot(lotId);

        return parkingLot
                .map(ResponseEntity::ok)  // Return the parking lot with a 200 OK if found
                .orElseGet(() -> ResponseEntity.status(HttpStatus.NOT_FOUND).build());  // Return 404 Not Found if not found
    }

    // POST Request: Add a new parking lot
    @PostMapping("/parking-lot")
    public ResponseEntity<ParkingLot> addParkingLot(@RequestBody ParkingLot parkingLot) {
        // Validate the ParkingLot data
        if (parkingLot.getLotId() == null || parkingLot.getLotId().trim().isEmpty()) {
            return ResponseEntity.badRequest().build();  // Return 400 Bad Request if lotId is missing
        }

        // Optionally, check if the ParkingLot already exists
        Optional<ParkingLot> existingParkingLot = parkingLotService.getParkingLot(parkingLot.getLotId());
        if (existingParkingLot.isPresent()) {
            return ResponseEntity.status(HttpStatus.CONFLICT).build();  // Return 409 Conflict if the lotId already exists
        }

        // Add the new parking lot
        ParkingLot newParkingLot = parkingLotService.addParkingLot(parkingLot);
        return ResponseEntity.status(HttpStatus.CREATED).body(newParkingLot); // Return 201 Created for successful addition
    }
}
