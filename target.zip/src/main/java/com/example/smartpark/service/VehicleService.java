package com.example.smartpark.service;

import com.example.smartpark.api.model.Vehicle;
import com.example.smartpark.repository.VehicleRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;
@Service
public class VehicleService {
    private final VehicleRepository vehicleRepository;
    private final ParkingLotService parkingLotService;
    private final ParkingSpotRepository parkingSpotRepository;

    public VehicleService(VehicleRepository vehicleRepository) {
        this.vehicleRepository = vehicleRepository;
    }
    public Optional<Vehicle> getVehicle(String id) {
        return vehicleRepository.findById(id);
    }

    public Vehicle addVehicle(Vehicle vehicle) {
        return vehicleRepository.save(vehicle);
    }
}
