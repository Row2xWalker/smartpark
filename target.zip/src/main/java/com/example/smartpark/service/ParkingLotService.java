package com.example.smartpark.service;

import com.example.smartpark.api.model.ParkingLot;
import com.example.smartpark.repository.ParkingLotRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class ParkingLotService {
    private final ParkingLotRepository parkingLotRepository;

    public ParkingLotService(ParkingLotRepository parkingLotRepository) {
        this.parkingLotRepository = parkingLotRepository;
    }
    public Optional<ParkingLot> getParkingLot(String id) {
        return parkingLotRepository.findById(id);
    }

    public ParkingLot addParkingLot(ParkingLot parkingLot) {
        return parkingLotRepository.save(parkingLot);
    }
}
