package com.example.smartpark;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SmartparkApplicationTests {

	@Test
	void contextLoads() {
	}

}
